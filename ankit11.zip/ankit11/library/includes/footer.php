   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                  <center>   Management System |<a href="#" target="_blank"  > </a> </center>
                </div>

            </div>
        </div>
    </section>