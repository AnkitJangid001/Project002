<?php
session_start();
error_reporting(0);
include('includes/config.php');
  include("connection.php");
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title> Management System |</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />

    <!-- custom css -->
    <link rel="stylesheet" type="text/css"  href="css/main.css" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
	<div class="container">
    <div class="row">
      <div class="col-lg-4"></div>
       <div class="col-lg-4 form-container">
         <h4 class="text-center">Student form</h4>
         <!-- form start here -->
          <form method="post" action="dashboard.php" enctype="multipart/form-data">
         
          
          <div class="form-group">
           <label>*Name:</label>
           <input class="form-control"  type="text" name="name" placeholder="enter your name..">
          </div>
<div class="form-group">
           <label>*Email:</label>
<input class="form-control" type="email" id="email" name="email"   placeholder="enter your Email..">

          <div class="form-group">
           <label>*Photo:</label>
           <input class="form-control"  type="file" name="file1"  id="file1" placeholder="your photo..">
          </div>
		  
		  <div class="form-group">
           <label>*video:</label>
           <input class="form-control"  type="file" name="file2" id="file2" placeholder="your video..">
          </div>
           
     
          <!-- submit button -->
           <input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit">
		   
		   
         </form>
       </div>
	   

		
		
		 
       <div class="col-lg-4"></div>
    </div><!-- row closed -->
	
</div><!-- container closed --> 

<?php	   
if(isset($_POST['submit'])){


	$name= $_POST['name'];
	$email=$_POST['email'];
	$file1=$_FILES['file1'];
	$fileName1=$_FILES['file1']['name'];
	$fileTmpName1=$_FILES['file1']['tmp_name'];
	$fileSize1=$_FILES['file1']['size'];
	$fileError1=$_FILES['file1']['error'];
	$fileType1=$_FILES['file1']['type'];
	
	$file2=$_FILES['file2'];
	$fileName2=$_FILES['file2']['name'];
	$fileTmpName2=$_FILES['file2']['tmp_name'];
	$fileSize2=$_FILES['file2']['size'];
	$fileError2=$_FILES['file2']['error'];
	$fileType2=$_FILES['file2']['type'];
	
	
	$fileExt1=explode('.',$fileName1);
	$fileActualExt1=strtolower(end($fileExt1));

  $fileExt2=explode('.',$fileName2);
  $fileActualExt2=strtolower(end($fileExt2));

	$allowed=array('jpg','jpeg','png','pdf','docx','txt','js','cpp','c','mp3','mp4','mkv','zip','sql','pptx','php','mpa','rar','z','csv','sql','xml','exe','py','gif','css','html','xls','xlr');
if(in_array($fileActualExt1,$allowed) && in_array($fileActualExt2,$allowed))
	{
		if($fileError1 === 0 && $fileError2 === 0){
					if($fileSize1<900000000 &&  $fileSize2<900000000)
					{
						// $fileNameNew=uniqid('',true).".".$fileActualExt;
						$fileDestination1='uploads/'.basename($fileName1);
                    $fileDestination2='uploads/'.basename($fileName2);
						move_uploaded_file($fileTmpName1, $fileDestination1);
            move_uploaded_file($fileTmpName2, $fileDestination2);
					   include('connection.php');
						$query="INSERT INTO ankit (name,email,photo,video) VALUES ('$name','$email','$fileName1','$fileName2')";
						mysqli_query($conn,$query);

					}else
					{
						echo '<div class="alert alert-danger" role="alert">Your file is too big!</div>';			
					}
		}else{
			echo '<div class="alert alert-danger" role="alert">There was an error uploading your file!</div>';
		}
	}else
	{
		echo '<div class="alert alert-danger" role="alert">You cannot upload files of this type!</div>';
	 }


}

?>
 
	<?php
 include("connection.php");
 $sql = "SELECT * FROM ankit ORDER BY id DESC;";
 $data = mysqli_query($conn,$sql);
 $total = mysqli_num_rows($data);
 $result = mysqli_fetch_all($data,MYSQLI_ASSOC);
 //check records
 if($total != 0){
   echo "";
 }else{
   echo "No records Found";
 }
?>
	
	 <div class="container pt-3">
   <h3 class="text-center">View Data</h3><br>
    <div class="row text-center">
      <div class="col-lg-12">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Photo</th>
              <th>video</th>             
              <th colspan="2">Update or Delete</th>
            </tr>
         </thead>
         <tbody>
            <?php

               foreach ($result as $value) { ?>
                  <tr>
                    <td><?php echo $value['name']; ?></td>
                    <td><?php echo $value['email']; ?></td>
                    <td><a href="Downloadfile1.php?Download=<?php echo $value['id'];?>"><?php echo $value['photo']; ?></a></td>
                     <td><a href="Downloadfile2.php?Download=<?php echo $value['id'];?>"><?php echo $value['video']; ?></a></td>
                  
                    <td><a href="update.php?sn=<?php echo $value['name'];?> & en=<?php echo $value['email'];?> & cp=<?php echo $value['photo'];?> & cv=<?php echo $value['video'];?>" class="btn btn-primary btn-sm">update</a></td>
                    <td><a onclick="return checkDelete()" href="delete.php?id=<?php echo $value['id'];?>" class="btn btn-danger btn-sm">delete</a></td>
                 </tr>
                <?php
                 }
                ?>     
          </tbody>           
     </table>
    <div>
 </div><!-- row -->
</div><!-- container -->
<script type="text/javascript">
   function checkDelete(){
      return confirm("Are you sure that you want to delete this record?");
   }
</script>
 <div class="container mt-5 text-center">

 </div>
	
	
	
     <!-- CONTENT-WRAPPER SECTION END-->
<?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>