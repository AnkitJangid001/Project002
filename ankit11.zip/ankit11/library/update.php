<?php
  error_reporting(0);
  include("connection.php");
  $sn = $_GET['sn'];
  $en = $_GET['en'];
  $cp = $_GET['cp'];
  $cv= $_GET['cv'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Update data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
   <link rel="stylesheet" type="text/css"  href="css/main.css" />
</head>
<body>
  <div class="container-fluid px-5">
    <div class="row">
      <div class="col-lg-4"></div>
       <div class="col-lg-4 form-container">
         <h4 class="text-center">Update Details</h4>
         <!-- form start here -->
          <form method="post" action="" enctype="multipart/form-data">
		  
		  <div class="form-group">
           <label>*Name:</label>
           <input class="form-control"  type="text" name="name" placeholder="enter your name.." value="<?php echo $sn;?>">
          </div>
<div class="form-group">
           <label>*Cateegory:</label>
<input class="form-control" type="text" id="category" name="category"   placeholder="enter your category.." value="<?php echo $ca;?>">

          <div class="form-group">
           <label>severity</label>
           <input class="form-control"  type="text" name="file1"   placeholder="enter your severity.." value="<?php echo $se;?>"cp>
          </div>
		  
		  <div class="form-group">
           <label>PLATFORM:</label>
           <input class="form-control"  type="text" name="PLATFORM"  placeholder="enter your platform.." value="<?php echo $pl;?>">
          </div>
		  
		  <div class="form-group">
           <label>Target:</label>
           <input class="form-control"  type="text" name="target"  placeholder="enter your target.." value="<?php echo $pl;?>">
          </div>
		  
		  <div class="form-group">
           <label>Action:</label>
           <input class="form-control"  type="text" name="Action"  placeholder="enter your platform.." value="<?php echo $Ac;?>">
          </div>
             <input type="submit" class="btn btn-info btn-block" name="submit" value="Click to Update">
     

		   <div class="container mt-5 text-center">
 &nbsp;  &nbsp;   <a class="btn btn-info btn-sm mt-3" href="form.php">go back to previous page </a>
 </div>
         </form>
       </div>
       <div class="col-lg-4"></div>
    </div><!-- row closed -->
</div><!-- container closed --> 

 <?php     
if(isset($_POST['submit'])){


  $name= $_POST['name'];
  $email=$_POST['email'];
  $file1=$_FILES['file1'];
  $fileName1=$_FILES['file1']['name'];
  $fileTmpName1=$_FILES['file1']['tmp_name'];
  $fileSize1=$_FILES['file1']['size'];
  $fileError1=$_FILES['file1']['error'];
  $fileType1=$_FILES['file1']['type'];
  
  $file2=$_FILES['file2'];
  $fileName2=$_FILES['file2']['name'];
  $fileTmpName2=$_FILES['file2']['tmp_name'];
  $fileSize2=$_FILES['file2']['size'];
  $fileError2=$_FILES['file2']['error'];
  $fileType2=$_FILES['file2']['type'];
  
  
  $fileExt1=explode('.',$fileName1);
  $fileActualExt1=strtolower(end($fileExt1));

  $fileExt2=explode('.',$fileName2);
  $fileActualExt2=strtolower(end($fileExt2));

  $allowed=array('jpg','jpeg','png','pdf','docx','txt','js','cpp','c','mp3','mp4','mkv','zip','sql','pptx','php','mpa','rar','z','csv','sql','xml','exe','py','gif','css','html','xls','xlr');
if(in_array($fileActualExt1,$allowed) && in_array($fileActualExt2,$allowed))
  {
    if($fileError1 === 0 && $fileError2 === 0){
          if($fileSize1<900000000 &&  $fileSize2<900000000)
          {
            // $fileNameNew=uniqid('',true).".".$fileActualExt;
            $fileDestination1='uploads/'.basename($fileName1);
                    $fileDestination2='uploads/'.basename($fileName2);
            move_uploaded_file($fileTmpName1, $fileDestination1);
            move_uploaded_file($fileTmpName2, $fileDestination2);
             include('connection.php');
            $query="INSERT INTO ankit (name,email,photo,video) VALUES ('$name','$email','$fileName1','$fileName2')";
            mysqli_query($conn,$query);

          }else
          {
            echo '<div class="alert alert-danger" role="alert">Your file is too big!</div>';      
          }
    }else{
      echo '<div class="alert alert-danger" role="alert">There was an error uploading your file!</div>';
    }
  }else
  {
    echo '<div class="alert alert-danger" role="alert">You cannot upload files of this type!</div>';
   }


}

?>
</body>
</html>